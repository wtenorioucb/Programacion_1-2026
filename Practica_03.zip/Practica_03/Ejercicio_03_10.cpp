// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main()
{
    system("cls");
    string texto;
    cout << "Ingrese una palabra palindroma:";
    getline(cin, texto);
    cout << texto << endl;
    for (int i = 0; i < texto.length(); i++)
    {
        if (i == 0 || texto[i - 1] == ' ')
        {
            if (texto[i] >= 'a' && texto[i] <= 'z')
            {
                texto[i] = texto[i] - 32;
            }
        }
    }
    cout << "El texto corregido es:" << texto << endl;

    return 0;
}