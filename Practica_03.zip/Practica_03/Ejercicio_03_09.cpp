// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <vector>
#include <string>
using namespace std;
bool palindromo(string letra);
int main()
{
    system("cls");
    string texto;
    cout << "Ingrese una palabra palindroma:";
    getline(cin, texto);
    cout << texto << endl;
    if (palindromo(texto))
    {
        cout << "Es un palindromo:";
    }
    else
    {
        cout << "No es un Palindromo:";
    }

    return 0;
}
bool palindromo(string letra)
{
    string palabra = "";
    for (int i = 0; i < letra.length(); i++)
    {
        if (letra[i] >= 'A' && letra[i] <= 'Z' || letra[i] >= 'a' && letra[i] <= 'z')
        {
            palabra = palabra + letra[i];
        }
    }
    int i = 0;
    int j = palabra.length() - 1;
    while (i < j)
    {
        if (letra[i] != letra[j])
        {
            return false;
        }
        i++;
        j--;
    }
    return true;
}
