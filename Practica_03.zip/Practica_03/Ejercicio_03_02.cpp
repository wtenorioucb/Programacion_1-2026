// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    system("cls");
    vector<string> Empresa1 = {"Kevin", "yosner", "mateo", "marco", "monce"};
    vector<string> Empresa2 = {"Kevin", "yosner", "marco", "monce"};
    cout << "Clientes en Comun:";
    for (int i = 0; i < Empresa1.size(); i++)
    {
        for (int j = 0; j < Empresa2.size(); j++)
        {
            if (Empresa1[i] == Empresa2[j])
            {
                cout << Empresa1[i] << ", ";
            }
        }
    }

    return 0;
}