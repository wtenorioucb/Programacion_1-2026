// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <vector>
#include <string>
using namespace std;
int main()
{
    system("cls");
    string letra;
    string palabra;
    cout << "Ingrese palabras separadas por comas:";
    getline(cin, letra);
    cout << letra << endl;
    for (int i = 0; i < letra.length(); i++)
    {
        if (letra[i] == ',')
        {
            if (palabra != "")
            {
                cout << palabra << endl;
                palabra = "";
            }
        }
        else
        {
            palabra = palabra + letra[i];
        }
    }
    if (palabra != "")
    {
        cout << palabra << endl;
    }

    return 0;
}