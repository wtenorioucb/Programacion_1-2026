// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace std;
int main()
{
    srand(time(0));
    system("cls");
    int n = 0;
    int posicion;
    cout << "Ingrese el numero de veces que apareceran nombres aleatorios:";
    cin >> n;

    vector<string> nombres = {"kevin", "marco", "mateo"};
    vector<string> apellidos = {"sucaticona", "rodriguez", "oliveira"};
    vector<string> edades = {"18", "25", "20"};
    for (int i = 0; i < n; i++)
    {
        posicion = rand() % 3;
        cout << "Persona" << i + 1 << ": ";
        cout << nombres[posicion] << " ";
        cout << apellidos[posicion] << "_";
        cout << edades[posicion] << " anios " << " " << endl;
    }

    return 0;
}
