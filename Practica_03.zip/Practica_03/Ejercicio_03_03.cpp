// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace std;
int GenerarAleatorio(int limInf, int limSup);
int main()
{
    system("cls");
    srand(time(0));
    int n = 0;
    int reprobados = 0;
    int regulares = 0;
    int buenos = 0;
    int excelente = 0;
    double porcetaje = 0;
    cout << "Ingrese el Numero de notas de Estudiantes:";
    cin >> n;
    int nota;
    vector<int> notas;
    for (int i = 0; i < n; i++)
    {
        nota = GenerarAleatorio(1, 100);
        notas.push_back(nota);
        if (nota <= 51)
        {
            reprobados++;
        }
        if (nota >= 60 && nota <= 79)
        {
            regulares++;
        }
        if (nota >= 80 && nota <= 89)
        {
            buenos++;
        }
        if (nota >= 90 && nota <= 100)
        {
            excelente++;
        }
    }
    for (int i = 0; i < notas.size(); i++)
    {
        cout << notas[i] << " ";
    }
    cout << "\nReprobados\n";
    porcetaje = ((double)reprobados / n) * 100;
    cout << porcetaje << "%" << endl;
    cout << "\nRegulares\n";
    porcetaje = ((double)regulares / n) * 100;
    cout << porcetaje << "%" << endl;
    cout << "\nBuenos\n";
    porcetaje = ((double)buenos / n) * 100;
    cout << porcetaje << "%" << endl;
    cout << "\nExcelente\n";
    porcetaje = ((double)excelente / n) * 100;
    cout << porcetaje << "%" << endl;

    return 0;
}
int GenerarAleatorio(int limInf, int limSup)
{
    double aleatorio = 0;
    aleatorio = rand() % (limSup - limInf + 1) + limInf;
    return aleatorio;
}
