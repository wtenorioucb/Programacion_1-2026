// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace std;
bool BuscarPuntoArroba(string email);
bool VerificarArrobas(string email);
int PosicionLetra(string email, char letra);
int main()
{
    system("cls");
    string email;
    cout << "Ingrese un Email:";
    getline(cin, email);
    if (VerificarArrobas(email))
    {
        if (BuscarPuntoArroba(email))
        {
            cout << "El email es valido:";
        }
        else
        {
            cout << "El email no es valido:";
        }
    }

    return 0;
}
bool VerificarArrobas(string email)
{
    int contador = 0;
    for (int i = 0; i < email.size(); i++)
    {
        if (email[i] == '@')
        {
            contador++;
        }
    }
    if (contador == 1)
    {
        return true;
    }
    else
    {
        return false;
    }
}
int PosicionLetra(string email, char letra)
{
    int posicion = -1;
    for (int i = 0; i < email.size(); i++)
    {
        if (email[i] == letra)
        {
            posicion = i;
        }
    }
    return posicion;
}
bool BuscarPuntoArroba(string email)
{
    for (int i = PosicionLetra(email, '@'); i < email.size(); i++)
    {
        if (email[i] == '.')
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}