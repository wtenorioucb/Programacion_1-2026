// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 13/04/2026
#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main()
{
    system("cls");
    string letra;
    string resultado;
    cout << "Ingrese numeros y letras aleatoriamente:";
    getline(cin, letra);
    cout << letra;
    for (int i = 0; i < letra.length(); i++)
    {
        if (!(letra[i] >= '0' && letra[i] <= '9'))
        {
            resultado = resultado + letra[i];
        }
    }
    cout << "El texto sin numeros resulta en:" << resultado << endl;

    return 0;
}