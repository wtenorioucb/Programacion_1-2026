// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 27/03/2026 
#include <iostream>
#include <vector>

using namespace std;
int GenerarAleatorio(int limInf, int limSup);
int main()
{
    system("cls");
    int n = 0;
    int m = 0;
    cout << "Ingrese el tamano del Vector 1:";
    cin >> n;
    cout << "Ingrese el tamano del Vector 2:";
    cin >> m;
    int numero;
    int numero2;
    vector<int> primero;
    vector<int> segundo;
    vector<int> resultado;

    for (int i = 0; i < n; i++)
    {
        numero = GenerarAleatorio(1, 10);
        primero.push_back(numero);
    }
    for (int i = 0; i < m; i++)
    {
        numero2 = GenerarAleatorio(1, 10);
        segundo.push_back(numero2);
    }
    cout << "\nVector 1:\n";
    for (int i = 0; i < primero.size(); i++)
    {
        cout << primero[i] << " ";
    }
    cout << "\nVector 2:\n";
    for (int i = 0; i < segundo.size(); i++)
    {
        cout << segundo[i] << " ";
    }

    int limite = min(primero.size(), segundo.size()); // limite = min (sirve para evitar calculos inexactos) :

    for (int i = 0; i < limite; i++)
    {
        resultado.push_back(primero[i] * segundo[i]);
    }
    cout << "\nProducto Vectores:\n";
    for (int i = 0; i < resultado.size(); i++)
    {
        cout << resultado[i] << " ";
    }

    return 0;
}
int GenerarAleatorio(int limInf, int limSup)
{
    double aleatorio = 0;
    aleatorio = rand() % (limSup - limInf + 1) + limInf;
    return aleatorio;
}
