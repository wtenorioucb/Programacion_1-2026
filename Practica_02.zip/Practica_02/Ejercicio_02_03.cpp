// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 27/03/2026 
#include <iostream>
#include <vector>
using namespace std;
int main()
{
    system("cls");
    int n = 0;
    float SumaNotas = 0;
    float Promedio = 0;
    float Desviacion = 0;
    float Varianza = 0;
    cout << "Ingrese las Notas del Estudiante:";
    cin >> n;
    vector<float> calificaciones(n);
    for (int i = 0; i < calificaciones.size(); i++)
    {
        cout << "calificaciones" << i + 1 << " ";
        cin >> calificaciones[i];
    }
    for (int i = 0; i < calificaciones.size(); i++)
    {
        SumaNotas += calificaciones[i];
        Promedio = (float)SumaNotas / n;
    }

    cout << "La Suma de las Notas es:" << SumaNotas << endl;
    cout << "El Promedio de las Notas es:" << Promedio << endl;

    cout << "La Desviacion en cada Punto:" << endl;
    for (int i = 0; i < n; i++)
    {
        Desviacion = calificaciones[i] - Promedio;
        cout << "Calificacion" << i + 1 << ":" << Desviacion << endl;
    }

    cout << "La Desviacion Al lado del Numero:" << endl;
    for (int i = 0; i < n; i++)
    {
        Desviacion = calificaciones[i] - Promedio;
        cout << calificaciones[i] << " ---- " << Desviacion << endl;
    }
    float sumacuadrados = 0;
    for (int i = 0; i < n; i++)
    {
        Desviacion = calificaciones[i] - Promedio;
        Varianza = Varianza + (Desviacion * Desviacion);
        float sumacuadrados = sumacuadrados + (Varianza / n);
        cout << "la varianza es de:" << sumacuadrados << endl;
    }

    return 0;
}
