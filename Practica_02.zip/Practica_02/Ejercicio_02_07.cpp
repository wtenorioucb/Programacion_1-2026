// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 27/03/2026 
#include <iostream>
#include <vector>

using namespace std;

int main()
{
    system("cls");
    int n = 0;
    int valor;
    cout << "Ingrese el tamano del Vector:";
    cin >> n;
    vector<int> numero;
    for (int i = 0; i < n; i++)
    {
        cout << "Numero" << i + 1 << ": "; // Para crear una lista sirve el i+1
        cin >> valor;
        if (valor < 0)
        {
            break; // Interrumpe el codigo si se cumple la condicion
        }
        numero.push_back(valor);  
    }
    for (int i = 0; i < numero.size(); i++)
    {
        cout << numero[i] << " ";
    }

    return 0;
}
