// Materia: Programación I, Paralelo 4 
// Autor: Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 13/04/2026 
#include <iostream>
using namespace std;

int main()
{
    system("cls");

    int matrix1[100][100];
    int matrix2[100][100];
    int MatrixResultado[100][100];
    int MatrixTranspuesta[100][100];

    int filas1, columnas1;
    int filas2, columnas2;

    cout << "Ingrese filas matriz 1: ";
    cin >> filas1;
    cout << "Ingrese columnas matriz 1: ";
    cin >> columnas1;

    cout << "Ingrese filas matriz 2: ";
    cin >> filas2;
    cout << "Ingrese columnas matriz 2: ";
    cin >> columnas2;

    if (columnas1 != filas2)
    {
        cout << "No se pueden multiplicar las matrices." << endl;
    }

    cout << "Ingrese matriz 1:" << endl;
    for (int i = 0; i < filas1; i++)
    {
        for (int j = 0; j < columnas1; j++)
        {
            cin >> matrix1[i][j];
        }
    }

    cout << "Ingrese matriz 2:" << endl;
    for (int i = 0; i < filas2; i++)
    {
        for (int j = 0; j < columnas2; j++)
        {
            cin >> matrix2[i][j];
        }
    }

    // matrix multiplicacion
    for (int i = 0; i < filas1; i++)
    {
        for (int j = 0; j < columnas2; j++)
        {
            MatrixResultado[i][j] = 0;
            for (int k = 0; k < columnas1; k++)
            {
                MatrixResultado[i][j] += matrix1[i][k] * matrix2[k][j];
            }
        }
    }

    cout << "Matriz resultado Multiplicacion:" << endl;
    for (int i = 0; i < filas1; i++)
    {
        for (int j = 0; j < columnas2; j++)
        {
            cout << MatrixResultado[i][j] << " ";
        }
        cout << endl;
    }

    for (int i = 0; i < filas1; i++)
    {
        for (int j = 0; j < columnas2; j++)
        {
            MatrixTranspuesta[j][i] = MatrixResultado[i][j];
        }
    }

    cout << "Matriz transpuesta de la Multiplicacion:" << endl;
    for (int i = 0; i < columnas2; i++)
    {
        for (int j = 0; j < filas1; j++)
        {
            cout << MatrixTranspuesta[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}