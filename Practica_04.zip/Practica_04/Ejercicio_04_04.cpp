// Materia: Programación I, Paralelo 4 
// Autor: Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 13/04/2026 
#include <iostream>
#include <vector>
using namespace std;
int main()
{
    system("cls");
    int matrix1[100][100];
    int filas1 = 0;
    int columnas1 = 0;
    cout << "Ingrese el numero de Filas:";
    cin >> filas1;
    cout << "Ingrese el numero de Columnas:";
    cin >> columnas1;
    for (int i = 0; i < filas1; i++)
    {
        for (int j = 0; j < columnas1; j++)
        {
            matrix1[i][j] = 2 * i + j + 1;
        }
        cout << endl;
    }
    for (int i = 0; i < filas1; i++)
    {
        for (int j = 0; j < columnas1; j++)
        {
            cout << matrix1[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}