// Materia: Programación I, Paralelo 4 
// Autor: Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 13/04/2026 #include <iostream>
#include <iostream>
#include <vector>

using namespace std;
int main()
{
    system("cls");
    int matrix1[100][100];
    int matrix2[100][100];
    int filas = 0;
    int columnas = 0;
    cout << "Digite el numero de fila:";
    cin >> filas;
    cout << "Digite el numero de columnas:";
    cin >> columnas;

    for (int i = 0; i < filas; i++)
    {
        for (int j = 0; j < columnas; j++)
        {
            cin >> matrix1[i][j];
        }
        cout << "\n";
    }
    for (int j = 0; j < columnas; j++)
    {
        int aux = matrix1[0][j];
        matrix1[0][j] = matrix1[filas - 1][j];
        matrix1[filas - 1][j] = aux;
    }

    cout << "\n\n";
    for (int i = 0; i < filas; i++)
    {
        for (int j = 0; j < columnas; j++)
        {
            cout << matrix1[i][j] << " ";
        }
        cout << "\n";
    }

    return 0;
}