// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 11/09/2025 
#include <iostream>

using namespace std;

double CalcularVolumen(double altura, double radio);

int main()
{
    system("cls");
    double radio = 0;
    double altura = 0;
    const double pi = 3.141592;

    cout << "ingrese el radio:";
    cin >> radio;
    cout << "ingrese la altura:";
    cin >> altura;

    cout << "El Volumen es de:" << CalcularVolumen(radio, altura) * pi << endl;

    return 0;
}

double CalcularVolumen(double altura, double radio)
{
    double resultado = radio * radio * altura;
    return resultado;
}
