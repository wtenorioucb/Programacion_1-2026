// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 11/09/2025 
#include <iostream>
using namespace std;

// Función solicitada
void agregarNota(double &sumaTotal, int &cantidadNotas, double nuevaNota)
{
    sumaTotal += nuevaNota;
    cantidadNotas++;
}

int main()
{
    system("cls");

    double sumaTotal = 0;
    int cantidadNotas = 0;
    double nuevaNota;
    int N;

    cout << "Cuantas notas desea ingresar: ";
    cin >> N;

    for (int i = 0; i < N; i++)
    {
        cout << "Ingrese la nota " << i + 1 << ": ";
        cin >> nuevaNota;

        agregarNota(sumaTotal, cantidadNotas, nuevaNota);
    }

    cout << "\nSuma total de notas: " << sumaTotal << endl;
    cout << "Cantidad de notas: " << cantidadNotas << endl;
    cout << "Promedio: " << sumaTotal / cantidadNotas << endl;

    return 0;
}