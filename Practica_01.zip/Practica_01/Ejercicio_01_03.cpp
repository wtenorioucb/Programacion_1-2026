// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 11/09/2025 
#include <iostream>

using namespace std;

void ModificarValores(int ValorEntero, int &ValorReferencia);

int main()
{
    system("cls");
    int a = 0;
    int b = 0;
    cout << "ingrese el 1er Valor:";
    cin >> a;
    cout << "ingrese el 2do Valor:";
    cin >> b;
    ModificarValores(a, b);
    cout << "el 1er valor cambio a:" << a << endl;
    cout << "el 2do valor cambio a:" << b << endl;

    return 0;
}

void ModificarValores(int ValorEntero, int &ValorReferencia)
{

    ValorEntero = ValorEntero * 2,
    ValorReferencia += 10;
}