// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 11/09/2025 
#include <iostream>
#include <vector>
using namespace std;
double CalcularPrecioTotal(double PrecioBase, double impuesto = 13);
int main()
{
    system("cls");
    double a = 0;
    cout << "ingrese el Precio del Producto:";
    cin >> a;
    cout << "el iva es de:" << CalcularPrecioTotal(a);

    return 0;
}

double CalcularPrecioTotal(double PrecioBase, double impuesto)
{
    double total = PrecioBase + (PrecioBase * impuesto / 100);
    return total;
}
