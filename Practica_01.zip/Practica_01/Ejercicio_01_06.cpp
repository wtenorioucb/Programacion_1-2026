// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 11/09/2025 
#include <iostream>

using namespace std;
void CalcularTiempo(int TotalSegundos, int &horas, int &minutos, int &segundos);
int main()
{
    system("cls");
    int segundosentrada, horas, minutos, segundos;
    cout << "Ingrese los segundos:";
    cin >> segundosentrada;
    CalcularTiempo(segundosentrada, horas, minutos, segundos);
    cout << "El tiempo es de:" << horas << "h" << minutos << "min" << segundos << "s" << endl;
    return 0;
}
void CalcularTiempo(int totalSegundos, int &horas, int &minutos, int &segundos)
{
    horas = totalSegundos / 3600;
    minutos = (totalSegundos % 3600) / 60;
    segundos = totalSegundos % 60;
}