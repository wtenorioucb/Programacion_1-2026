// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez
// Fecha creación: 11/09/2025 
#include <iostream>

using namespace std;
double CalcularArea(double lado);
double AreaRectangulo(double base, double altura);
float AreaCirculo(float radio, float Pi);
int main()
{
    system("cls");
    double lado, base, altura = 0;
    float radio = 0;
    const float Pi = 3.141596;

    cout << "Ingrese el lado de un cuadrado:";
    cin >> lado;
    cout << "Ingrese la base de un rectangulo:";
    cin >> base;
    cout << "Ingrese la altura de un rectangulo:";
    cin >> altura;
    cout << "ingrese el radio para un circulo:";
    cin >> radio;

    cout << "El area de un cuadrado es :" << CalcularArea(lado) << endl;
    cout << "El area de un Rectangulo es :" << AreaRectangulo(base, altura) << endl;
    cout << "El area de un Circulo es:" << AreaCirculo(radio, Pi);
    return 0;
}

double CalcularArea(double lado)
{
    double resultado = lado * lado;
    return resultado;
}
double AreaRectangulo(double base, double altura)
{
    double resultado = base * altura;
    return resultado;
}
float AreaCirculo(float radio, float Pi)
{
    float resultado = radio * radio * Pi;
    return resultado;
}
